<?php

// File Location: /core/index.php

header("Location: ../site/login/");

?>