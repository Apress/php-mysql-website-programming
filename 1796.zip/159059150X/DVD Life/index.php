<?php

header("Location: site/news/");

?>